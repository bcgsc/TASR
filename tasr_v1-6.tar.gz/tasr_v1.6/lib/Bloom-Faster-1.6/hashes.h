
BIGNUM hash1(char *str);
BIGNUM hash2(char *str);
BIGNUM hash3(char *str);
BIGNUM hash4(char *str);
BIGNUM hash5(char *str);


